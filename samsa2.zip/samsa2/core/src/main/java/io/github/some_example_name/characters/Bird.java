package io.github.some_example_name.characters;

import static io.github.some_example_name.GameSettings.scr_height;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Circle;

public class Bird {
    public float x, y;
    public float width, height;

    float velocity = 0;
    float gravity = 0.6f;
    float jumpStrength = 12f;

    public Circle bounds;

    int frameCounter;
    Texture[] framesArray;

    public Bird(float x, float y, float width, float height){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        frameCounter = 0;

        framesArray = new Texture[]{
            new Texture("ptichka/ptichka.png"),
            new Texture("ptichka/ptichka2.png"),
            new Texture("ptichka/ptichka.png"),
        };

        bounds = new Circle(x + width / 2, y + height / 2, width / 4.0f);
    }

    public void setY(float y){
        this.y = y;
        this.velocity = 0;
        updateBounds();
    }

    public void onClick(){
        velocity = jumpStrength;
    }

    public void fly(){
        velocity -= gravity;
        y += velocity;
        updateBounds();
    }

    private void updateBounds() {
        bounds.setPosition(x + width / 2, y + height / 2);
    }

    public boolean isInField(){
        return y > 0 && y < scr_height;
    }

    public void draw(Batch batch){
        int frameMultiplier = 10;

        batch.draw(framesArray[frameCounter / frameMultiplier], x, y, width, height);

        if (frameCounter++ == framesArray.length * frameMultiplier - 1) frameCounter = 0;
    }

    public void dispose(){
        for(Texture texture : framesArray){
            texture.dispose();
        }
    }
}
