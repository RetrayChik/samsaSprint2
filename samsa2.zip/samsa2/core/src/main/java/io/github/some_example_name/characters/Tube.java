package io.github.some_example_name.characters;

import static io.github.some_example_name.GameSettings.scr_height;
import static io.github.some_example_name.GameSettings.scr_width;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;

import java.util.Random;

public class Tube {
    Texture textureVerx;
    Texture textureniz;
    Random random;
    float x, gapY;
    float distnceTrub;
    boolean pointReseve;
    float speed = 6;

    final float width = 150;
    final float height = 800;

    float gapHeight = 250;
    float padding = 150;

    Rectangle boundsTop;
    Rectangle boundsBot;

    public Tube(int tubeCount, int tubeIdx){
        random = new Random();

        distnceTrub = (scr_width * 1.5f) / (float)tubeCount;
        x = scr_width + distnceTrub * tubeIdx;

        boundsTop = new Rectangle();
        boundsBot = new Rectangle();

        generateGapY();

        textureVerx = new Texture("tubes/verx.png");
        textureniz = new Texture("tubes/niz.png");

        pointReseve = false;
        updateBounds();
    }

    private void generateGapY() {
        gapY = padding + random.nextInt((int)(scr_height - 2 * padding));
    }

    private void updateBounds() {
        float insetX = 45f;

        float insetY = 40f;

        boundsTop.set(
            x + insetX,
            gapY + gapHeight / 2 + insetY,
            width - 2 * insetX,
            height - insetY
        );

        boundsBot.set(
            x + insetX,
            gapY - gapHeight / 2 - height,
            width - 2 * insetX,
            height - insetY
        );
    }

    public void draw(Batch batch){
        batch.draw(textureVerx, x, gapY + gapHeight / 2, width, height);
        batch.draw(textureniz, x, gapY - gapHeight / 2 - height, width, height);
    }

    public void move(){
        x -= speed;
        updateBounds();

        if(x < -width){
            pointReseve = false;
            x += distnceTrub * 3;
            generateGapY();
            updateBounds();
        }
    }

    public boolean isHit(Bird bird){
        if (Intersector.overlaps(bird.bounds, boundsTop)) return true;
        if (Intersector.overlaps(bird.bounds, boundsBot)) return true;
        return false;
    }

    public boolean needAddPoint(Bird bird){
        if (!pointReseve && bird.x > x + width) {
            pointReseve = true;
            return true;
        }
        return false;
    }

    public void setPointReseved(){
        pointReseve = true;
    }

    public void dispose(){
        textureniz.dispose();
        textureVerx.dispose();
    }
}
