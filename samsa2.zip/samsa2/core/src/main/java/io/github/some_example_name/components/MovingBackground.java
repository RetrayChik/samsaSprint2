package io.github.some_example_name.components;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;

import io.github.some_example_name.GameSettings;

public class MovingBackground {
    Texture texture;
    float texture1, texture2;
    int speed = 4;

    public MovingBackground(String pathToTexture){
        texture1 = 0;
        texture2 = GameSettings.scr_width;
        texture = new Texture(pathToTexture);
    }

    public void move(){
        texture1 -= speed;
        texture2 -= speed;

        if (texture1 <= -GameSettings.scr_width){
            texture1 = GameSettings.scr_width;
        }
        if (texture2 <= -GameSettings.scr_width){
            texture2 = GameSettings.scr_width;
        }
    }

    public void draw(Batch batch){
        batch.draw(texture, texture1, 0, GameSettings.scr_width, GameSettings.scr_height);
        batch.draw(texture, texture2, 0, GameSettings.scr_width, GameSettings.scr_height);
    }

    public void dispose(){
        texture.dispose();
    }
}
