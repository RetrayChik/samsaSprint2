package io.github.some_example_name.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;
import io.github.some_example_name.GameSettings;
import io.github.some_example_name.components.MovingBackground;
import io.github.some_example_name.components.PointCounter;
import io.github.some_example_name.components.TextButton;

public class ScreenRestart implements Screen {
    GameSettings gameSettings;
    MovingBackground background;
    PointCounter pointCounter;
    TextButton buttonRestart;
    TextButton buttonMenu;

    public int gamePoints;

    public ScreenRestart(GameSettings gameSettings){
        this.gameSettings = gameSettings;

        pointCounter = new PointCounter(-10, 350);
        buttonRestart = new TextButton(0, 300, "Restart");
        buttonMenu = new TextButton(0, 50, "Menu");
        background = new MovingBackground("fony/noch.png");
    }

    @Override
    public void show(){

    }

    @Override
    public void render(float delta){
        if (Gdx.input.justTouched()){
            Vector3 touch = gameSettings.camera.unproject(
                new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0)
            );
            if (buttonRestart.isHit((int) touch.x, (int) touch.y)){
                gameSettings.setScreen(gameSettings.screenGame);
            }
            if (buttonMenu.isHit((int) touch.x, (int) touch.y)){
                gameSettings.setScreen(gameSettings.screenMenu);
            }
        }

        ScreenUtils.clear(0, 0, 0, 1);
        gameSettings.camera.update();
        gameSettings.batch.setProjectionMatrix(gameSettings.camera.combined);
        gameSettings.batch.begin();

        background.draw(gameSettings.batch);
        buttonMenu.draw(gameSettings.batch);
        buttonRestart.draw(gameSettings.batch);
        pointCounter.draw(gameSettings.batch, gamePoints);

        gameSettings.batch.end();
    }

    @Override
    public void resize(int width, int height){

    }

    @Override
    public void pause(){

    }

    @Override
    public void resume(){

    }

    @Override
    public void hide(){

    }

    @Override
    public void dispose(){
        background.dispose();
        buttonRestart.dispose();
        buttonMenu.dispose();
        pointCounter.dispose();
    }
}
