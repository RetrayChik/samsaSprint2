package io.github.some_example_name.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;

import io.github.some_example_name.GameSettings;
import io.github.some_example_name.components.MovingBackground;
import io.github.some_example_name.components.TextButton;

public class ScreenMenu implements Screen {
    GameSettings gameSettings;
    MovingBackground background;
    TextButton buttonStart;
    TextButton buttonExit;

    public ScreenMenu(GameSettings gameSettings){
        this.gameSettings = gameSettings;


        buttonStart = new TextButton(0, 300, "Start");
        buttonExit = new TextButton(0, 50, "Exit");
        background = new MovingBackground("fony/noch.png");
    }

    @Override
    public void show(){

    }

    @Override
    public void render(float delta) {
        if (Gdx.input.justTouched()) {
            Vector3 touch = gameSettings.camera.unproject(
                new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0)
            );

            if (buttonStart.isHit((int) touch.x, (int) touch.y)) {
                gameSettings.setScreen(gameSettings.screenGame);
            }
            if (buttonExit.isHit((int) touch.x, (int) touch.y)) {
                Gdx.app.exit();
            }
        }


        ScreenUtils.clear(0, 0, 0, 1);
        gameSettings.camera.update();

        gameSettings.batch.setProjectionMatrix(gameSettings.camera.combined);

        gameSettings.batch.begin();

        background.draw(gameSettings.batch);
        buttonStart.draw(gameSettings.batch);
        buttonExit.draw(gameSettings.batch);

        gameSettings.batch.end();
    }

    @Override
    public void resize(int width, int height){

    }

    @Override
    public void pause(){

    }

    @Override
    public void resume(){

    }

    @Override
    public void hide(){

    }

    @Override
    public void dispose(){
        background.dispose();
        buttonExit.dispose();
        buttonStart.dispose();
    }
}
